// file under test
import UpdatedPackagesCollector from "../src/UpdatedPackagesCollector";

describe("UpdatedPackagesCollector", () => {
  it("should exist", () => {
    expect(UpdatedPackagesCollector).toBeDefined();
  });

  it("needs better tests");
});
