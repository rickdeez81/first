#!/usr/bin/env node

const msg = require("./");

console.log("cli", msg);
