"use strict";

const msg = require("@integration/package-1");

module.exports = `package-2 ${msg}`;
