#!/usr/bin/env node

const msg = require("@integration/package-1");

console.log("package-3", "cli1", msg);
