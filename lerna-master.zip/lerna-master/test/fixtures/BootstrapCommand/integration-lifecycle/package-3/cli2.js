#!/usr/bin/env node

const msg = require("@integration/package-2");

console.log("package-3", "cli2", msg);
