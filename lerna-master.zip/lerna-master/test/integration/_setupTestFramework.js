/* global jasmine */
"use strict";

// allow CLI integration tests to run for awhile
jasmine.DEFAULT_TIMEOUT_INTERVAL = 300000;
